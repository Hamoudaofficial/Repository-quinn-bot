import { db, doc, getDoc, setDoc, updateDoc } from './firebase_config.js';

class StateManager {
    constructor() {
        this.user = null;
        this.dirty = false;
        this.syncInterval = 300000; // 5 minutes strategy to reduce reads/writes
        this.cacheKey = 'quinn_user_2026';
    }

    async initUser(tgUser) {
        const docRef = doc(db, 'users', String(tgUser.id));
        const cached = localStorage.getItem(this.cacheKey);
        
        if (cached) {
            this.user = JSON.parse(cached);
        }

        try {
            const snap = await getDoc(docRef);
            if (snap.exists()) {
                this.user = { ...this.user, ...snap.data() };
                this.resetDailyLimits();
                localStorage.setItem(this.cacheKey, JSON.stringify(this.user));
            } else {
                this.user = this.getDefaultUser(tgUser);
                await setDoc(docRef, this.user);
            }
        } catch (e) {
            console.error("Firebase Read Failed, using cache", e);
        }
        
        this.startSyncCycle();
        return this.user;
    }

    getDefaultUser(tg) {
        return {
            id: String(tg.id),
            name: tg.first_name || 'Quinn User',
            tokens: 1000,
            quinn: 0.1,
            energy: 1000,
            lastSeen: Date.now(),
            pin: "1234", 
            isVerified: false,
            aiAttempts: 5,
            lastAiReset: Date.now(),
            goldGrams: 0,
            passiveRate: 10,
            level: 1,
            history: []
        };
    }

    resetDailyLimits() {
        const today = new Date().toDateString();
        const lastReset = new Date(this.user.lastAiReset).toDateValue ? new Date(this.user.lastAiReset).toDateString() : "";
        if (today !== lastReset) {
            this.user.aiAttempts = 5;
            this.user.lastAiReset = Date.now();
            this.dirty = true;
        }
    }

    updateLocal(data) {
        this.user = { ...this.user, ...data };
        this.dirty = true;
        localStorage.setItem(this.cacheKey, JSON.stringify(this.user));
    }

    async syncToFirebase() {
        if (!this.dirty || !this.user) return;
        const docRef = doc(db, 'users', this.user.id);
        try {
            await updateDoc(docRef, this.user);
            this.dirty = false;
            console.log("💎 Firebase Synced (5m Strategy)");
        } catch (e) {
            console.error("Sync Error", e);
        }
    }

    startSyncCycle() {
        setInterval(() => this.syncToFirebase(), this.syncInterval);
        

        setInterval(() => {
            if(this.user) {
                this.updateLocal({ tokens: this.user.tokens + (this.user.passiveRate / 3600) });
            }
        }, 1000);
    }
}

export const state = new StateManager();
