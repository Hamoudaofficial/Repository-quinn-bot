import { state } from './state_manager.js';

const GEMINI_KEY = "AIzaSyD6OJry2vr1oxENsI4Ibkru8oDTdPMEu2Y";

export async function askGemini(prompt, user) {
    if (user.aiAttempts <= 0) return "لقد استنفدت محاولاتك اليومية (5/5). عد غداً!";

    try {
        const targetUrl = `https://generativelanguage.googleapis.com/v1beta/models/gemini-pro:generateContent?key=${GEMINI_KEY}`;
        const proxyUrl = "https://dev-edge.flowith.net/api-proxy/" + encodeURIComponent(targetUrl);

        const response = await fetch(proxyUrl, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
                contents: [{ parts: [{ text: `You are the AI assistant of Quinn Bot 2026. Current user: ${user.name}. User query: ${prompt}` }] }]
            })
        });

        const data = await response.json();
        const reply = data.candidates[0].content.parts[0].text || "لم أستطع معالجة طلبك حالياً.";
        
        state.updateLocal({ aiAttempts: user.aiAttempts - 1 });
        return reply;

    } catch (e) {
        console.error("AI Error", e);
        return "حدث خطأ في الاتصال بنظام Gemini.";
    }
}
