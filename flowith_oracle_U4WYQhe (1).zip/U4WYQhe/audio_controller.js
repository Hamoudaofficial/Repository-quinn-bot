const SOUNDS = {
    tap: 'https://assets.mixkit.co/active_storage/sfx/2571/2571-preview.mp3',
    success: 'https://assets.mixkit.co/active_storage/sfx/1435/1435-preview.mp3',
    nav: 'https://assets.mixkit.co/active_storage/sfx/2568/2568-preview.mp3'
};

export function playSound(key) {
    const audio = new Audio(SOUNDS[key]);
    audio.volume = 0.3;
    audio.play().catch(() => {}); // Ignore autoplay blocks
}
