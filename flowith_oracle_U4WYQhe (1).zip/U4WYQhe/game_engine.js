import { state } from './state_manager.js';

class GameEngine {

    async playSega(opponentType, betAmount) {
        if (state.user.tokens < betAmount) return { winner: 'none' };


        const winChance = 0.25; 
        const isWin = Math.random() < winChance;

        if (isWin) {
            state.updateLocal({ tokens: state.user.tokens + betAmount });
            return { winner: 'player' };
        } else {
            state.updateLocal({ tokens: state.user.tokens - betAmount });
            return { winner: 'opponent' };
        }
    }


    handleGameResult(success, reward, penalty) {
        if (success) {
            state.updateLocal({ tokens: state.user.tokens + reward });
            return true;
        } else {

            state.updateLocal({ tokens: Math.max(0, state.user.tokens - penalty) });
            return false;
        }
    }
}

export const games = new GameEngine();
