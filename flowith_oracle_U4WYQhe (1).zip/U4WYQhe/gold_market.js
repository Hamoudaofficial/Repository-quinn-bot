import { db, doc, getDoc, updateDoc } from './firebase_config.js';
import { state } from './state_manager.js';

class GoldMarket {
    constructor() {
        this.price = 1850.50;
        this.liquidity = 100000000;
        this.marketDoc = doc(db, 'economy', 'gold_market');
    }

    async init(callback) {
        try {
            const snap = await getDoc(this.marketDoc);
            if (snap.exists()) {
                this.price = snap.data().price;
            }
            if (callback) callback({ price: this.price });
        } catch (e) {
            console.warn("Using local gold price fallback");
        }
    }

    async trade(grams, type) {
        const costTokens = grams * this.price * 100; // Conversion logic

        if (type === 'buy') {
            if (state.user.tokens < costTokens) return false;
            
            const newPrice = this.price + (grams * 0.5); // Buying increases price
            state.updateLocal({ 
                tokens: state.user.tokens - costTokens,
                goldGrams: state.user.goldGrams + grams 
            });
            await this.updateGlobalPrice(newPrice);
            return true;
        } else {
            if (state.user.goldGrams < grams) return false;
            
            const newPrice = this.price - (grams * 0.5); // Selling decreases price
            state.updateLocal({ 
                tokens: state.user.tokens + (costTokens * 0.98), // 2% fee
                goldGrams: state.user.goldGrams - grams 
            });
            await this.updateGlobalPrice(newPrice);
            return true;
        }
    }

    async updateGlobalPrice(newPrice) {
        this.price = newPrice;
        try {
            await updateDoc(this.marketDoc, { price: newPrice, lastUpdate: Date.now() });
        } catch (e) {
            console.error("Market Update Failed", e);
        }
    }
}

export const goldMarket = new GoldMarket();
