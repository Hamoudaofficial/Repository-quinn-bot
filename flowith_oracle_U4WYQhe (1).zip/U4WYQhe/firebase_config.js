import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.0/firebase-app.js";
import { getFirestore, doc, getDoc, setDoc, updateDoc, enableIndexedDbPersistence, collection, query, orderBy, limit, getDocs } from "https://www.gstatic.com/firebasejs/10.12.0/firebase-firestore.js";

const firebaseConfig = {
    apiKey: "AIzaSyDYyxW9P-_DlOEqK6FCQqqBWo5UFxGnshY",
    authDomain: "quinnbot-9f797.firebaseapp.com",
    databaseURL: "https://quinnbot-9f797-default-rtdb.firebaseio.com",
    projectId: "quinnbot-9f797",
    storageBucket: "quinnbot-9f797.firebasestorage.app",
    messagingSenderId: "592205334333",
    appId: "1:592205334333:web:9f8a3b6ec7e7fee81fa754",
    measurementId: "G-W5HRWB45GX"
};

const app = initializeApp(firebaseConfig);
const db = getFirestore(app);


enableIndexedDbPersistence(db).catch((err) => {
    if (err.code == 'failed-precondition') {
        console.warn("Multiple tabs open, persistence can only be enabled in one tab at a time.");
    } else if (err.code == 'unimplemented') {
        console.warn("The current browser does not support all of the features required to enable persistence");
    }
});

export { db, doc, getDoc, setDoc, updateDoc, collection, query, orderBy, limit, getDocs };
