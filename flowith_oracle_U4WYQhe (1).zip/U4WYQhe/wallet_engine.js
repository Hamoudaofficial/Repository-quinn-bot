import { state } from './state_manager.js';

class WalletEngine {
    generateReceiveCode() {
        return `QW2026-${state.user.id}-${state.user.name.substring(0,2).toUpperCase()}`;
    }

    async secureTransfer(amount, targetId, pin) {

        if (state.user.pin !== pin) throw "رمز PIN غير صحيح";
        if (state.user.quinn < amount) throw "رصيد كوين غير كافٍ";
        
        state.updateLocal({ quinn: state.user.quinn - amount });

        return true;
    }
}

export const wallet = new WalletEngine();
