import { state } from './state_manager.js';
import { games } from './game_engine.js';
import { goldMarket } from './gold_market.js';
import { wallet } from './wallet_engine.js';
import { askGemini } from './ai_helper.js';
import { playSound } from './audio_controller.js';
import { db, collection, query, orderBy, limit, getDocs } from './firebase_config.js';

const tg = window.Telegram?.WebApp;
const BUY_PIN = "T9@xQ#4mL!2vZ$7pR";

class App {
    constructor() {
        this.currentTab = 'home';
        this.init();
    }

    async init() {

        if (!tg || !tg.initData || tg.platform === 'unknown') {
            document.getElementById('restriction-screen').classList.remove('hidden');
            return;
        }

        tg.expand();
        tg.enableClosingConfirmation();
        tg.headerColor = '#000000';

        try {
            const user = await state.initUser(tg.initDataUnsafe?.user || { id: 777, first_name: 'Dev' });
            this.updateUI();
            this.attachEvents();
            this.hideLoading();
            playSound('nav');
        } catch (e) {
            console.error("Initialization Failed", e);
        }
    }

    hideLoading() {
        document.getElementById('load-progress').style.width = '100%';
        setTimeout(() => {
            document.getElementById('loading-screen').classList.add('hidden');
            document.getElementById('app').classList.replace('opacity-0', 'opacity-100');
            lucide.createIcons();
        }, 800);
    }

    updateUI() {
        document.getElementById('display-name').textContent = state.user.name;
        document.getElementById('main-balance').innerHTML = `${state.user.quinn.toFixed(4)} <span class="text-xs">Q</span>`;
        document.getElementById('token-count').textContent = `${Math.floor(state.user.tokens)} TOKENS`;
        if (state.user.isVerified) document.getElementById('verify-badge').classList.remove('hidden');
        
        this.renderTab(this.currentTab);
    }

    renderTab(tabName) {
        const container = document.getElementById('tab-container');
        container.innerHTML = '';
        
        if (tabName === 'home') this.renderHome(container);
        if (tabName === 'wallet') this.renderWallet(container);
        if (tabName === 'gold') this.renderGold(container);
        if (tabName === 'games') this.renderGames(container);
        if (tabName === 'ai') this.renderAI(container);
        if (tabName === 'stats') this.renderStats(container);
        
        lucide.createIcons();
    }

    renderHome(el) {
        el.innerHTML = `
            <div class="flex flex-col items-center py-6">
                <button id="main-tap-btn" class="w-56 h-56 rounded-full bg-gradient-to-tr from-violet-900 to-amber-500 p-1 active:scale-90 transition-all shadow-[0_0_50px_-10px_rgba(139,92,246,0.5)]">
                    <div class="w-full h-full rounded-full bg-black/40 backdrop-blur-xl flex items-center justify-center border border-white/20">
                        <span class="text-7xl">🪙</span>
                    </div>
                </button>
                <div class="mt-6 flex items-center gap-2 text-amber-500 font-bold bg-white/5 px-4 py-2 rounded-full border border-white/10">
                    <i data-lucide="zap" class="w-4 h-4 fill-current"></i>
                    <span id="energy-val">${Math.floor(state.user.energy)} / 1000</span>
                </div>
            </div>
            
            <div class="grid grid-cols-2 gap-4">
                <div class="glass-card p-4">
                    <p class="text-[10px] text-white/40 mb-1 uppercase tracking-widest">معدل التعدين</p>
                    <div class="text-lg font-bold text-violet-400">⚡ ${state.user.passiveRate}/h</div>
                </div>
                <button id="buy-coins-btn" class="glass-card p-4 border-amber-500/30 flex flex-col items-start">
                    <p class="text-[10px] text-white/40 mb-1 uppercase">شراء عملات</p>
                    <div class="text-lg font-bold text-amber-500 flex items-center gap-1">
                        متجر <i data-lucide="shopping-cart" class="w-4 h-4"></i>
                    </div>
                </button>
            </div>
        `;
        
        document.getElementById('main-tap-btn').addEventListener('click', () => {
            if (state.user.energy > 0) {
                state.updateLocal({ tokens: state.user.tokens + 1, energy: state.user.energy - 1 });
                playSound('tap');
                this.updateUI();
            }
        });

        document.getElementById('buy-coins-btn').onclick = () => {
            const pin = prompt("أدخل الرقم السري لعملية الشراء:");
            if (pin === BUY_PIN) {
                const amount = confirm("هل تريد شراء 50,000 توكن مقابل 0.01 Q؟");
                if (amount && state.user.quinn >= 0.01) {
                    state.updateLocal({ quinn: state.user.quinn - 0.01, tokens: state.user.tokens + 50000 });
                    alert("تمت العملية بنجاح!");
                    this.updateUI();
                } else {
                    alert("رصيد كوين غير كافٍ");
                }
            } else {
                alert("رقم سري خاطئ!");
            }
        };
    }

    renderWallet(container) {
        const barcode = wallet.generateReceiveCode();
        container.innerHTML = `
            <div class="glass-card p-6 mb-4 relative overflow-hidden">
                <div class="absolute top-0 right-0 w-32 h-32 bg-amber-500/10 blur-3xl rounded-full -mr-16 -mt-16"></div>
                <div class="flex justify-between items-start mb-10">
                    <div>
                        <p class="text-[10px] text-white/40 uppercase font-bold tracking-tighter">قيمة المحفظة</p>
                        <h1 class="text-4xl font-black text-white mt-1">${state.user.quinn.toFixed(4)} <span class="text-xl text-amber-500">Q</span></h1>
                    </div>
                    <i data-lucide="wallet" class="text-white/20 w-8 h-8"></i>
                </div>
                <div class="flex gap-3">
                    <button class="flex-1 py-3 bg-white text-black rounded-2xl font-black text-sm active:scale-95" id="send-btn">تحويل</button>
                    <button class="flex-1 py-3 glass-card rounded-2xl font-black text-sm active:scale-95" id="receive-btn">استلام</button>
                </div>
            </div>

            <div class="glass-card p-6 flex flex-col items-center">
                <div class="w-full flex justify-between items-center mb-4">
                    <span class="text-xs font-bold text-white/60">QR Code الخاص بك</span>
                    <i data-lucide="qr-code" class="w-4 h-4"></i>
                </div>
                <div class="bg-white p-2 rounded-xl mb-4">
                   <img src="https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=${barcode}" class="w-32 h-32" alt="QR">
                </div>
                <p class="text-[9px] font-mono text-amber-500/80 bg-amber-500/5 px-3 py-1 rounded-full border border-amber-500/20">${barcode}</p>
            </div>
        `;
    }

    renderGold(container) {
        goldMarket.init((data) => {
            const el = document.getElementById('gold-price-val');
            if(el) el.textContent = data.price.toFixed(2);
        });

        container.innerHTML = `
            <div class="glass-card p-6">
                <div class="flex justify-between mb-6">
                    <div>
                        <p class="text-[10px] text-amber-500 font-bold uppercase">سوق الذهب الديناميكي</p>
                        <h2 class="text-3xl font-black">$<span id="gold-price-val">${goldMarket.price.toFixed(2)}</span></h2>
                    </div>
                    <div class="text-right">
                        <p class="text-[10px] text-white/40 uppercase font-bold">مخزونك</p>
                        <p class="text-lg font-bold">${state.user.goldGrams.toFixed(3)} g</p>
                    </div>
                </div>
                <canvas id="goldChart" class="w-full h-32 mb-6"></canvas>
                <div class="grid grid-cols-2 gap-4">
                    <button class="py-4 bg-green-500/20 border border-green-500/40 text-green-400 font-bold rounded-2xl" onclick="window.tradeGold('buy')">شراء</button>
                    <button class="py-4 bg-red-500/20 border border-red-500/40 text-red-400 font-bold rounded-2xl" onclick="window.tradeGold('sell')">بيع</button>
                </div>
            </div>
        `;
        
        this.initGoldChart();

        window.tradeGold = async (type) => {
            const amount = prompt(`أدخل الكمية بالجرام لـ ${type === 'buy' ? 'الشراء' : 'البيع'}:`, "0.1");
            if (amount > 0) {
                const success = await goldMarket.trade(parseFloat(amount), type);
                if (success) {
                    playSound('success');
                    this.updateUI();
                } else {
                    alert("رصيد غير كافٍ لإتمام العملية");
                }
            }
        };
    }

    initGoldChart() {
        const ctx = document.getElementById('goldChart')?.getContext('2d');
        if (!ctx) return;
        new Chart(ctx, {
            type: 'line',
            data: {
                labels: ['', '', '', '', '', ''],
                datasets: [{
                    data: [1800, 1820, 1815, 1850, 1840, goldMarket.price],
                    borderColor: '#f59e0b',
                    tension: 0.4,
                    borderWidth: 2,
                    pointRadius: 0,
                    fill: true,
                    backgroundColor: 'rgba(245, 158, 11, 0.1)'
                }]
            },
            options: { plugins: { legend: { display: false } }, scales: { x: { display: false }, y: { display: false } } }
        });
    }

    renderGames(container) {
        container.innerHTML = `
            <div class="space-y-4">
                <div class="glass-card p-6 border-red-500/30">
                    <div class="flex justify-between items-center mb-4">
                        <span class="px-2 py-0.5 bg-red-500 text-[8px] font-black rounded uppercase">HARDCORE</span>
                        <span class="text-xs text-white/40">جائزة: 5000 TOKENS</span>
                    </div>
                    <h3 class="text-lg font-bold mb-2">تحدي النبضة المفقودة</h3>
                    <p class="text-xs text-white/50 mb-6">انقر في اللحظة التي يختفي فيها اللون. الخطأ يعني خسارة 1000 توكن ولا جائزة.</p>
                    <button class="w-full py-3 bg-white/5 border border-white/10 rounded-xl font-bold active:bg-white/10" onclick="alert('اللعبة قيد التحميل...')">دخول التحدي</button>
                </div>

                <div class="glass-card p-6 border-violet-500/40 bg-gradient-to-br from-violet-600/10 to-transparent">
                    <h3 class="text-lg font-bold mb-1">لعبة سيجا (Sega 1vs1)</h3>
                    <p class="text-[10px] text-violet-300/60 mb-4 font-bold uppercase tracking-widest">مراهنات حية ضد لاعبين</p>
                    <button class="w-full py-3 bg-violet-600 text-white rounded-xl font-black shadow-lg shadow-violet-600/30" id="sega-btn">ابدأ الرهان الآن</button>
                </div>
            </div>
        `;

        document.getElementById('sega-btn').addEventListener('click', async () => {
            const bet = prompt("أدخل قيمة الرهان (TOKENS):", "500");
            if (bet && parseInt(bet) > 0) {
                const res = await games.playSega('peer', parseInt(bet));
                if (res.winner === 'player') {
                    alert("نصر ساحق! فزت بـ " + (bet * 2) + " توكن");
                    playSound('success');
                } else {
                    alert("خسرت الرهان. حاول مجدداً لاحقاً.");
                }
                this.updateUI();
            }
        });
    }

    renderAI(container) {
        container.innerHTML = `
            <div class="glass-card p-6">
                <div class="flex items-center gap-3 mb-6">
                    <div class="w-10 h-10 bg-violet-600 rounded-2xl flex items-center justify-center rotate-3 shadow-lg shadow-violet-600/20">
                        <i data-lucide="brain-circuit" class="text-white w-6 h-6"></i>
                    </div>
                    <div>
                        <h3 class="font-black text-sm">مساعد QUINN الذكي</h3>
                        <p class="text-[9px] text-white/40 uppercase">المحاولات: ${state.user.aiAttempts}/5 المتبقية</p>
                    </div>
                </div>
                <div id="ai-chat" class="h-60 overflow-y-auto mb-4 text-xs space-y-4 scroll-smooth">
                    <div class="bg-white/5 p-3 rounded-2xl rounded-tl-none border border-white/5">كيف يمكنني مساعدتك في إدارة محفظتك اليوم؟</div>
                </div>
                <div class="flex gap-2 p-1 bg-white/5 rounded-2xl border border-white/10 focus-within:border-violet-500/50 transition-all">
                    <input id="ai-input" class="flex-1 bg-transparent border-none px-3 py-2 text-xs outline-none" placeholder="اسأل Gemini...">
                    <button id="ai-send" class="p-2 bg-violet-600 rounded-xl active:scale-90 transition-all"><i data-lucide="send" class="w-4 h-4 text-white"></i></button>
                </div>
            </div>
        `;

        const btn = document.getElementById('ai-send');
        const input = document.getElementById('ai-input');
        const chat = document.getElementById('ai-chat');

        btn.onclick = async () => {
            const q = input.value.trim();
            if (!q || state.user.aiAttempts <= 0) return;
            
            chat.innerHTML += `<div class="bg-violet-600/20 p-3 rounded-2xl rounded-tr-none text-right border border-violet-500/20">${q}</div>`;
            input.value = '';
            chat.scrollTop = chat.scrollHeight;

            const res = await askGemini(q, state.user);
            chat.innerHTML += `<div class="bg-white/5 p-3 rounded-2xl rounded-tl-none border border-white/5">${res}</div>`;
            chat.scrollTop = chat.scrollHeight;
            this.updateUI();
        };
    }

    async renderStats(container) {
        container.innerHTML = `<div class="p-10 text-center animate-pulse text-white/20 uppercase tracking-widest text-xs">جاري جلب لوحة الصدارة...</div>`;
        
        try {
            const q = query(collection(db, 'users'), orderBy('quinn', 'desc'), limit(10));
            const snap = await getDocs(q);
            
            let listHtml = '';
            let rank = 1;
            snap.forEach(doc => {
                const u = doc.data();
                listHtml += `
                    <div class="flex items-center justify-between p-4 glass-card mb-2 ${u.id === state.user.id ? 'border-amber-500/50 bg-amber-500/5' : ''}">
                        <div class="flex items-center gap-3">
                            <span class="text-xs font-black text-white/30 w-4">#${rank++}</span>
                            <div class="w-8 h-8 rounded-full bg-violet-600/20 flex items-center justify-center text-[10px] font-bold">${u.name[0]}</div>
                            <span class="text-sm font-bold">${u.name}</span>
                        </div>
                        <div class="text-right">
                            <div class="text-xs font-black text-amber-500">${u.quinn.toFixed(4)} Q</div>
                            <div class="text-[8px] text-white/40 uppercase">${u.tokens.toLocaleString()} TOKENS</div>
                        </div>
                    </div>
                `;
            });

            container.innerHTML = `
                <div class="mb-4 flex items-center gap-2">
                    <i data-lucide="trophy" class="text-amber-500 w-5 h-5"></i>
                    <h2 class="text-xl font-black">قائمة العظماء</h2>
                </div>
                ${listHtml}
            `;
            lucide.createIcons();
        } catch(e) {
            container.innerHTML = `<div class="p-10 text-center text-red-400">فشل في تحميل البيانات.</div>`;
        }
    }

    attachEvents() {
        document.querySelectorAll('.nav-item').forEach(btn => {
            btn.onclick = () => {
                document.querySelectorAll('.nav-item').forEach(b => b.classList.remove('active'));
                btn.classList.add('active');
                this.currentTab = btn.dataset.tab;
                this.updateUI();
                playSound('nav');
            };
        });
        
        document.getElementById('settings-btn').onclick = () => {
            alert("إعدادات QUINN OS 2026\nإصدار: 2.0.26\nالحالة: متصل\nتشفير: AES-256");
        };
    }
}

window.addEventListener('DOMContentLoaded', () => {
    new App();
});
